package com.konecta.convertly.enums;

public enum TimeUnit {
    SECOND("second"),
    MINUTE("minute"),
    HOUR("hour"),
    DAY("day");

    private final String value;

    TimeUnit(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static TimeUnit fromString(String value) {
        for (TimeUnit unit : TimeUnit.values()) {
            if (unit.value.equalsIgnoreCase(value)) {
                return unit;
            }
        }
        throw new IllegalArgumentException("Unknown time unit: " + value);
    }
}
