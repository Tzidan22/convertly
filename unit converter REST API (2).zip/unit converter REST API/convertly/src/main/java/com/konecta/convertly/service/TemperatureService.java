package com.konecta.convertly.service;

import com.konecta.convertly.enums.TemperatureUnit;
import org.springframework.stereotype.Service;

@Service
public class TemperatureService {

    public double convert(double value, TemperatureUnit fromUnit, TemperatureUnit toUnit) {
        if (fromUnit == toUnit) {
            return value;
        }

    
        double celsius = toCelsius(value, fromUnit);

       
        return fromCelsius(celsius, toUnit);
    }

    private double toCelsius(double value, TemperatureUnit unit) {
        switch (unit) {
            case CELSIUS:
                return value;
            case FAHRENHEIT:
                return (value - 32) * 5.0 / 9.0;
            case KELVIN:
                return value - 273.15;
            default:
                throw new IllegalArgumentException("Unsupported temperature unit: " + unit);
        }
    }

    private double fromCelsius(double celsius, TemperatureUnit unit) {
        switch (unit) {
            case CELSIUS:
                return celsius;
            case FAHRENHEIT:
                return (celsius * 9.0 / 5.0) + 32;
            case KELVIN:
                return celsius + 273.15;
            default:
                throw new IllegalArgumentException("Unsupported temperature unit: " + unit);
        }
    }

    public String getFormula(TemperatureUnit fromUnit, TemperatureUnit toUnit, double value) {
        if (fromUnit == toUnit) {
            return String.format("%.2f%s = %.2f%s", value, fromUnit.name().toLowerCase(), value, toUnit.name().toLowerCase());
        }

        switch (fromUnit) {
            case CELSIUS:
                if (toUnit == TemperatureUnit.FAHRENHEIT) {
                    return String.format("(%.2f°C × 9/5) + 32 = %.2f°F", value, convert(value, fromUnit, toUnit));
                } else if (toUnit == TemperatureUnit.KELVIN) {
                    return String.format("%.2f°C + 273.15 = %.2fK", value, convert(value, fromUnit, toUnit));
                }
                break;
            case FAHRENHEIT:
                if (toUnit == TemperatureUnit.CELSIUS) {
                    return String.format("(%.2f°F - 32) × 5/9 = %.2f°C", value, convert(value, fromUnit, toUnit));
                } else if (toUnit == TemperatureUnit.KELVIN) {
                    return String.format("(%.2f°F - 32) × 5/9 + 273.15 = %.2fK", value, convert(value, fromUnit, toUnit));
                }
                break;
            case KELVIN:
                if (toUnit == TemperatureUnit.CELSIUS) {
                    return String.format("%.2fK - 273.15 = %.2f°C", value, convert(value, fromUnit, toUnit));
                } else if (toUnit == TemperatureUnit.FAHRENHEIT) {
                    return String.format("(%.2fK - 273.15) × 9/5 + 32 = %.2f°F", value, convert(value, fromUnit, toUnit));
                }
                break;
        }
        return "";
    }
}
