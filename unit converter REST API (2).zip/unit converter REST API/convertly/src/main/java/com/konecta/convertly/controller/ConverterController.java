package com.konecta.convertly.controller;

import com.konecta.convertly.enums.*;
import com.konecta.convertly.exception.InvalidUnitException;
import com.konecta.convertly.model.ConversionRequest;
import com.konecta.convertly.model.ConversionResponse;
import com.konecta.convertly.service.ConversionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1")
public class ConverterController {

    private final ConversionService conversionService;

    public ConverterController(ConversionService conversionService) {
        this.conversionService = conversionService;
    }

    @PostMapping("/convert")
    public ConversionResponse convert(@Valid @RequestBody ConversionRequest request) {
        return conversionService.convert(request);
    }

    @GetMapping("/categories")
    public List<String> getCategories() {
        return Arrays.stream(Category.values())
                .map(Category::getValue)
                .collect(Collectors.toList());
    }

    @GetMapping("/units")
    public List<String> getUnits(@RequestParam String category) {
        try {
            Category cat = Category.fromString(category);
            switch (cat) {
                case TEMPERATURE:
                    return Arrays.stream(TemperatureUnit.values())
                            .map(TemperatureUnit::getValue)
                            .collect(Collectors.toList());
                case LENGTH:
                    return Arrays.stream(LengthUnit.values())
                            .map(LengthUnit::getValue)
                            .collect(Collectors.toList());
                case WEIGHT:
                    return Arrays.stream(WeightUnit.values())
                            .map(WeightUnit::getValue)
                            .collect(Collectors.toList());
                case TIME:
                    return Arrays.stream(TimeUnit.values())
                            .map(TimeUnit::getValue)
                            .collect(Collectors.toList());
                default:
                    return List.of();
            }
        } catch (IllegalArgumentException e) {
            throw new InvalidUnitException("Invalid category: " + category);
        }
    }

    @GetMapping("/sample-payload")
    public ConversionRequest getSamplePayload() {
        return new ConversionRequest(
            "temperature",
            "celsius",
            "fahrenheit",
            25.0
        );
    }

    @GetMapping("/health")
    public  String healthCheck() {
        ConversionResponse response = new ConversionResponse();
        response.setStatus("Unit Converter API is up and running");
        return response.getStatus();
    }
}
