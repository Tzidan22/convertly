package com.konecta.convertly.service;

import com.konecta.convertly.enums.TimeUnit;
import org.springframework.stereotype.Service;

@Service
public class TimeService {

    public double convert(double value, TimeUnit fromUnit, TimeUnit toUnit) {
        if (fromUnit == toUnit) {
            return value;
        }

        // Convert to seconds first
        double seconds = toSeconds(value, fromUnit);

        // Convert from seconds to target unit
        return fromSeconds(seconds, toUnit);
    }

    private double toSeconds(double value, TimeUnit unit) {
        switch (unit) {
            case SECOND:
                return value;
            case MINUTE:
                return value * 60;
            case HOUR:
                return value * 3600;
            case DAY:
                return value * 86400;
            default:
                throw new IllegalArgumentException("Unsupported time unit: " + unit);
        }
    }

    private double fromSeconds(double seconds, TimeUnit unit) {
        switch (unit) {
            case SECOND:
                return seconds;
            case MINUTE:
                return seconds / 60;
            case HOUR:
                return seconds / 3600;
            case DAY:
                return seconds / 86400;
            default:
                throw new IllegalArgumentException("Unsupported time unit: " + unit);
        }
    }

    public String getFormula(TimeUnit fromUnit, TimeUnit toUnit, double value) {
        if (fromUnit == toUnit) {
            return String.format("%.2f%s = %.2f%s", value, fromUnit.name().toLowerCase(), value, toUnit.name().toLowerCase());
        }

        double result = convert(value, fromUnit, toUnit);
        return String.format("%.2f%s = %.2f%s", value, fromUnit.name().toLowerCase(), result, toUnit.name().toLowerCase());
    }
}
