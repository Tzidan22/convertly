package com.konecta.convertly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConvertlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConvertlyApplication.class, args);
	}

}
