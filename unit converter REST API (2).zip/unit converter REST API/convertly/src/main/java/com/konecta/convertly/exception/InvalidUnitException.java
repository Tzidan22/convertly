package com.konecta.convertly.exception;

public class InvalidUnitException extends RuntimeException {
    public InvalidUnitException(String message) {
        super(message);
    }
}
