package com.konecta.convertly.service;

import com.konecta.convertly.enums.*;
import com.konecta.convertly.exception.InvalidUnitException;
import com.konecta.convertly.model.ConversionRequest;
import com.konecta.convertly.model.ConversionResponse;
import org.springframework.stereotype.Service;

@Service
public class ConversionService {

    private final TemperatureService temperatureService;
    private final LengthService lengthService;
    private final WeightService weightService;
    private final TimeService timeService;

    public ConversionService(TemperatureService temperatureService, LengthService lengthService,
                             WeightService weightService, TimeService timeService) {
        this.temperatureService = temperatureService;
        this.lengthService = lengthService;
        this.weightService = weightService;
        this.timeService = timeService;
    }

    public ConversionResponse convert(ConversionRequest request) {
        validateRequest(request);
        
        double result;
        String formula;
        
        switch (Category.fromString(request.getCategory())) {
            case TEMPERATURE:
                result = temperatureService.convert(
                    request.getValue(),
                    TemperatureUnit.fromString(request.getFromUnit()),
                    TemperatureUnit.fromString(request.getToUnit())
                );
                formula = temperatureService.getFormula(
                    TemperatureUnit.fromString(request.getFromUnit()),
                    TemperatureUnit.fromString(request.getToUnit()),
                    request.getValue()
                );
                break;
                
            case LENGTH:
                result = lengthService.convert(
                    request.getValue(),
                    LengthUnit.fromString(request.getFromUnit()),
                    LengthUnit.fromString(request.getToUnit())
                );
                formula = lengthService.getFormula(
                    LengthUnit.fromString(request.getFromUnit()),
                    LengthUnit.fromString(request.getToUnit()),
                    request.getValue()
                );
                break;
                
            case WEIGHT:
                result = weightService.convert(
                    request.getValue(),
                    WeightUnit.fromString(request.getFromUnit()),
                    WeightUnit.fromString(request.getToUnit())
                );
                formula = weightService.getFormula(
                    WeightUnit.fromString(request.getFromUnit()),
                    WeightUnit.fromString(request.getToUnit()),
                    request.getValue()
                );
                break;
                
            case TIME:
                result = timeService.convert(
                    request.getValue(),
                    TimeUnit.fromString(request.getFromUnit()),
                    TimeUnit.fromString(request.getToUnit())
                );
                formula = timeService.getFormula(
                    TimeUnit.fromString(request.getFromUnit()),
                    TimeUnit.fromString(request.getToUnit()),
                    request.getValue()
                );
                break;
                
            default:
                throw new InvalidUnitException("Unsupported category: " + request.getCategory());
        }
        
        return new ConversionResponse(result, formula, "success", request);
    }

    private void validateRequest(ConversionRequest request) {
        try {
            Category.fromString(request.getCategory());
            
            switch (Category.fromString(request.getCategory())) {
                case TEMPERATURE:
                    TemperatureUnit.fromString(request.getFromUnit());
                    TemperatureUnit.fromString(request.getToUnit());
                    break;
                case LENGTH:
                    LengthUnit.fromString(request.getFromUnit());
                    LengthUnit.fromString(request.getToUnit());
                    break;
                case WEIGHT:
                    WeightUnit.fromString(request.getFromUnit());
                    WeightUnit.fromString(request.getToUnit());
                    break;
                case TIME:
                    TimeUnit.fromString(request.getFromUnit());
                    TimeUnit.fromString(request.getToUnit());
                    break;
            }
        } catch (IllegalArgumentException e) {
            throw new InvalidUnitException("Invalid unit or category: " + e.getMessage());
        }
    }
}
