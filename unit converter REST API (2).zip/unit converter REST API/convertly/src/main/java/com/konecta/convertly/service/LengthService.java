package com.konecta.convertly.service;

import com.konecta.convertly.enums.LengthUnit;
import org.springframework.stereotype.Service;

@Service
public class LengthService {

    public double convert(double value, LengthUnit fromUnit, LengthUnit toUnit) {
        if (fromUnit == toUnit) {
            return value;
        }

        // Convert to meters first
        double meters = toMeters(value, fromUnit);

        // Convert from meters to target unit
        return fromMeters(meters, toUnit);
    }

    private double toMeters(double value, LengthUnit unit) {
        switch (unit) {
            case METER:
                return value;
            case KILOMETER:
                return value * 1000;
            case MILE:
                return value * 1609.34;
            case INCH:
                return value * 0.0254;
            case FOOT:
                return value * 0.3048;
            default:
                throw new IllegalArgumentException("Unsupported length unit: " + unit);
        }
    }

    private double fromMeters(double meters, LengthUnit unit) {
        switch (unit) {
            case METER:
                return meters;
            case KILOMETER:
                return meters / 1000;
            case MILE:
                return meters / 1609.34;
            case INCH:
                return meters / 0.0254;
            case FOOT:
                return meters / 0.3048;
            default:
                throw new IllegalArgumentException("Unsupported length unit: " + unit);
        }
    }

    public String getFormula(LengthUnit fromUnit, LengthUnit toUnit, double value) {
        if (fromUnit == toUnit) {
            return String.format("%.2f%s = %.2f%s", value, fromUnit.name().toLowerCase(), value, toUnit.name().toLowerCase());
        }

        double result = convert(value, fromUnit, toUnit);
        return String.format("%.2f%s = %.2f%s", value, fromUnit.name().toLowerCase(), result, toUnit.name().toLowerCase());
    }
}
