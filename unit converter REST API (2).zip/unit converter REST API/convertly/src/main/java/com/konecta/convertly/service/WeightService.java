package com.konecta.convertly.service;

import com.konecta.convertly.enums.WeightUnit;
import org.springframework.stereotype.Service;

@Service
public class WeightService {

    public double convert(double value, WeightUnit fromUnit, WeightUnit toUnit) {
        if (fromUnit == toUnit) {
            return value;
        }

        // Convert to grams first
        double grams = toGrams(value, fromUnit);

        // Convert from grams to target unit
        return fromGrams(grams, toUnit);
    }

    private double toGrams(double value, WeightUnit unit) {
        switch (unit) {
            case GRAM:
                return value;
            case KILOGRAM:
                return value * 1000;
            case POUND:
                return value * 453.592;
            case OUNCE:
                return value * 28.3495;
            default:
                throw new IllegalArgumentException("Unsupported weight unit: " + unit);
        }
    }

    private double fromGrams(double grams, WeightUnit unit) {
        switch (unit) {
            case GRAM:
                return grams;
            case KILOGRAM:
                return grams / 1000;
            case POUND:
                return grams / 453.592;
            case OUNCE:
                return grams / 28.3495;
            default:
                throw new IllegalArgumentException("Unsupported weight unit: " + unit);
        }
    }

    public String getFormula(WeightUnit fromUnit, WeightUnit toUnit, double value) {
        if (fromUnit == toUnit) {
            return String.format("%.2f%s = %.2f%s", value, fromUnit.name().toLowerCase(), value, toUnit.name().toLowerCase());
        }

        double result = convert(value, fromUnit, toUnit);
        return String.format("%.2f%s = %.2f%s", value, fromUnit.name().toLowerCase(), result, toUnit.name().toLowerCase());
    }
}
